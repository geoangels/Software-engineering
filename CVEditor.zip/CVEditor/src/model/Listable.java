package model;

import java.util.ArrayList;

public interface Listable {
	public ArrayList<Item> getItemList();
	public String getListableTitle();
}
