package model;

public class Chronological extends BasicCv{

	public Chronological(String name, String mobile, String phone, String address, String mail) {
		super(name, mobile, phone, address, mail);
	}

	@Override
	public void export() {
		
	}

}
