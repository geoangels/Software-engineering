package model;

public class Functional extends BasicCv{

	public Functional(String name, String mobile, String phone, String address, String mail) {
		super(name, mobile, phone, address, mail);
	}

	@Override
	public void export() {
		
	}

}
